package Cards.WildCards;

public enum WildType {
    WILD_CARD, WILD_DRAW_FOUR
}
