package Cards.ColoredCards;

public enum Color {
    YELLOW, RED, BLUE, GREEN
}
