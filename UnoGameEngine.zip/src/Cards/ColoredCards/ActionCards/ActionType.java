package Cards.ColoredCards.ActionCards;

public enum ActionType {
    DRAW_TWO, REVERSE, SKIP
}
