package Game;
public class GameDriver {
    public static void main(String[] args) {
        Game game = new UnoGame();
        game.play();
    }
}