package Game;

public interface Game {
    void play();
}